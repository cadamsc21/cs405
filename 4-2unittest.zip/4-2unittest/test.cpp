#include <gtest/gtest.h>
#include <vector>

class CollectionTest : public ::testing::Test {
protected:
    std::vector<int> vec;

    void SetUp() override {
        // Initial setup before each test
    }

    void TearDown() override {
        // Cleanup after each test
    }
};

// Positive Test: Ensure vector is initialized empty
TEST_F(CollectionTest, IsInitiallyEmpty) {
    EXPECT_TRUE(vec.empty());
}

// Positive Test: Add a single value to an empty collection
TEST_F(CollectionTest, AddSingleValue) {
    vec.push_back(1);
    EXPECT_EQ(vec.size(), 1);
    EXPECT_EQ(vec[0], 1);
}

// Positive Test: Add five values to the collection
TEST_F(CollectionTest, AddFiveValues) {
    for(int i = 1; i <= 5; ++i) {
        vec.push_back(i);
    }
    EXPECT_EQ(vec.size(), 5);
    for(int i = 0; i < 5; ++i) {
        EXPECT_EQ(vec[i], i+1);
    }
}

// Positive Test: Check maximum size and capacity
TEST_F(CollectionTest, MaxSizeAndCapacity) {
    vec.reserve(100);
    EXPECT_GE(vec.capacity(), 100);
}

// Positive Test: Resize the collection
TEST_F(CollectionTest, ResizeCollection) {
    vec.resize(10);
    EXPECT_EQ(vec.size(), 10);
    vec.resize(5);
    EXPECT_EQ(vec.size(), 5);
    vec.resize(0);
    EXPECT_TRUE(vec.empty());
}

// Positive Test: Clear the collection
TEST_F(CollectionTest, ClearCollection) {
    vec.push_back(1);
    vec.clear();
    EXPECT_TRUE(vec.empty());
}

// Positive Test: Erase all elements
TEST_F(CollectionTest, EraseAllElements) {
    vec = {1, 2, 3, 4, 5};
    vec.erase(vec.begin(), vec.end());
    EXPECT_TRUE(vec.empty());
}

// Positive Test: Reserve capacity
TEST_F(CollectionTest, ReserveCapacity) {
    vec.reserve(50);
    EXPECT_GE(vec.capacity(), 50);
}

// Negative Test: Access out of range
TEST_F(CollectionTest, AccessOutOfRange) {
    EXPECT_THROW(vec.at(10), std::out_of_range);
}

// Custom Positive Test: Verify pushing back increases size
TEST_F(CollectionTest, PushBackIncreasesSize) {
    auto initialSize = vec.size();
    vec.push_back(42);
    EXPECT_EQ(vec.size(), initialSize + 1);
}

// Custom Negative Test: Shrink to smaller than size
TEST_F(CollectionTest, ShrinkToSmallerThanSize) {
    vec = {1, 2, 3, 4, 5};
    vec.resize(2);
    EXPECT_EQ(vec.size(), 2);
    EXPECT_THROW(vec.at(4), std::out_of_range);
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
