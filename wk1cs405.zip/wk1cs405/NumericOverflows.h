#ifndef NUMERICOVERFLOWS_H
#define NUMERICOVERFLOWS_H

/// <summary>
/// Template function to abstract away the logic of:
/// start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps);

/// <summary>
/// Template function to abstract away the logic of:
/// start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps);

#endif //NUMERICOVERFLOWS_H
