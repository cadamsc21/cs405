//The 'main' function.
//

#include <iostfream>
#include <exception>

using namespace std;

// customException class that extends from std: :exception
struct CustomException : public std: :exception
{
    virtual const char* what() const throw()
    {
        return "Hello from John's custom exception!";
    }
};

bool do_even_more_custom_application_logic()
{
    //TODO: Throw any standard exception
    throw std: :bad_exception();

    std: :cout << "Running Even More Custom Application Logic." <<std: :end1;

    return true;
}
void do_custom_application_logic()
{
    //TODO: wrap the call to do_even_more_custom_application_logic()
    // with an exception handler that catches std: :exception, displays
    // a message and the exception.what(), then continues processing
    std: :cout << "Running Custom Application Logic." << std: :end1;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std: :cout << "Even More Custom Application Logic Succeeded." << std: :end1;
        }
    }
    catch (const std: :exception& exception)
    {
        std: :cerr << "Exception messege: " <<exception.what() << std: :end1;
    }

    //TODO: Throw a custom Exception derived from std: :exception
    //and catch it explictly in main
    throw CustomException();

    std: :cout << "Leaving Custom Application Logic." << std: :end1;

}

float divide(float num, float den)
{
    TODO: Throw an exception to deal with divide by zero errors using

